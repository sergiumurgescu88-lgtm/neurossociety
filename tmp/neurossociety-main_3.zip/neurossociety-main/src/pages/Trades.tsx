import { useState } from "react";
import { formatCurrencyPlain, formatCurrency } from "@/lib/format";
import { format } from "date-fns";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, LineChart, Line, AreaChart, Area, Legend } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface TradesPageProps {
  trades: any[];
  loading: boolean;
}

export default function TradesPage({ trades, loading }: TradesPageProps) {
  const [page, setPage] = useState(0);
  const [symbolFilter, setSymbolFilter] = useState<string>("ALL");
  const [typeFilter, setTypeFilter] = useState<string>("ALL");
  const [fromDate, setFromDate] = useState<Date>();
  const [toDate, setToDate] = useState<Date>();
  const perPage = 20;

  if (loading) {
    return (
      <div className="bg-card border border-border-subtle rounded-xl p-6 animate-pulse">
        {[1,2,3,4,5].map(i => <div key={i} className="h-10 bg-card-hover rounded mb-2" />)}
      </div>
    );
  }

  // Get unique symbols and types for filter dropdowns
  const uniqueSymbols = [...new Set(trades.map(t => t.symbol))].sort();
  const uniqueTypes = [...new Set(trades.map(t => t.type).filter(Boolean))].sort();
  
  // Apply filters
  const filteredTrades = trades.filter(t => {
    // Symbol filter
    if (symbolFilter !== "ALL" && t.symbol !== symbolFilter) return false;
    
    // Type filter
    if (typeFilter !== "ALL" && t.type !== typeFilter) return false;
    
    // Date range filter
    if (fromDate || toDate) {
      const tradeDate = new Date(t.timestamp);
      if (fromDate && tradeDate < fromDate) return false;
      if (toDate && tradeDate > toDate) return false;
    }
    
    return true;
  });

  const sorted = [...filteredTrades].sort((a, b) => new Date(b.timestamp ?? 0).getTime() - new Date(a.timestamp ?? 0).getTime());
  const totalPages = Math.ceil(sorted.length / perPage);
  const paged = sorted.slice(page * perPage, (page + 1) * perPage);
  
  const clearFilters = () => {
    setSymbolFilter("ALL");
    setTypeFilter("ALL");
    setFromDate(undefined);
    setToDate(undefined);
    setPage(0);
  };

  const hasActiveFilters = symbolFilter !== "ALL" || typeFilter !== "ALL" || fromDate || toDate;

  const buyTrades = filteredTrades.filter(t => t.action === "BUY");
  const sellTrades = filteredTrades.filter(t => t.action === "SELL");
  const totalInvested = buyTrades.reduce((s, t) => s + (t.value || (t.qty ?? 0) * (t.price ?? 0)), 0);
  const totalReturned = sellTrades.reduce((s, t) => s + (t.value || (t.qty ?? 0) * (t.price ?? 0)), 0);
  const netBalance = totalReturned - totalInvested;
  const wins = sellTrades.filter(t => (t.pl ?? 0) > 0).length;
  const winRate = sellTrades.length > 0 ? (wins / sellTrades.length * 100) : 0;
  const totalPl = sellTrades.reduce((s, t) => s + (t.pl ?? 0), 0);
  const bestTrade = sellTrades.length > 0 ? Math.max(...sellTrades.map(t => t.pl ?? 0)) : 0;

  // Pie chart data - investment distribution by symbol
  const PIE_COLORS = ["hsl(160,84%,39%)", "hsl(217,91%,60%)", "hsl(280,65%,60%)", "hsl(38,92%,50%)", "hsl(0,84%,60%)", "hsl(190,80%,45%)", "hsl(330,70%,55%)", "hsl(120,60%,40%)", "hsl(50,90%,55%)", "hsl(260,50%,65%)"];
  const symbolMap = new Map<string, number>();
  buyTrades.forEach(t => {
    const val = t.value || (t.qty ?? 0) * (t.price ?? 0);
    symbolMap.set(t.symbol, (symbolMap.get(t.symbol) ?? 0) + val);
  });
  const pieData = [...symbolMap.entries()]
    .map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))
    .sort((a, b) => b.value - a.value);

  // Performance charts data - based on filtered trades
  const createPerformanceCharts = () => {
    // Group trades by date
    const tradesByDate = new Map<string, { buys: any[], sells: any[], date: string }>();
    
    filteredTrades.forEach(t => {
      const dateKey = format(new Date(t.timestamp), 'yyyy-MM-dd');
      if (!tradesByDate.has(dateKey)) {
        tradesByDate.set(dateKey, { buys: [], sells: [], date: dateKey });
      }
      const dayData = tradesByDate.get(dateKey)!;
      if (t.action === 'BUY') dayData.buys.push(t);
      if (t.action === 'SELL') dayData.sells.push(t);
    });

    // Create cumulative P&L and volume charts data
    const sortedDates = Array.from(tradesByDate.keys()).sort();
    let cumulativePL = 0;
    
    return sortedDates.map(dateKey => {
      const dayData = tradesByDate.get(dateKey)!;
      const buyVolume = dayData.buys.reduce((sum, t) => sum + (t.value || (t.qty ?? 0) * (t.price ?? 0)), 0);
      const sellVolume = dayData.sells.reduce((sum, t) => sum + (t.value || (t.qty ?? 0) * (t.price ?? 0)), 0);
      const dayPL = dayData.sells.reduce((sum, t) => sum + (t.pl ?? 0), 0);
      cumulativePL += dayPL;
      
      const dayWins = dayData.sells.filter(t => (t.pl ?? 0) > 0).length;
      const dayWinRate = dayData.sells.length > 0 ? (dayWins / dayData.sells.length * 100) : 0;

      return {
        date: format(new Date(dateKey), 'dd/MM'),
        fullDate: dateKey,
        buyVolume: Math.round(buyVolume),
        sellVolume: Math.round(sellVolume),
        dailyPL: Math.round(dayPL * 100) / 100,
        cumulativePL: Math.round(cumulativePL * 100) / 100,
        winRate: Math.round(dayWinRate * 100) / 100,
        totalTrades: dayData.buys.length + dayData.sells.length
      };
    });
  };

  const performanceData = createPerformanceCharts();

  // P&L chart data - last 10 sell trades
  const plChartData = [...sellTrades]
    .sort((a, b) => new Date(a.timestamp ?? 0).getTime() - new Date(b.timestamp ?? 0).getTime())
    .slice(-10)
    .map((t, i) => ({
      name: t.symbol ?? `#${i + 1}`,
      pl: t.pl ?? 0,
    }));

  const typeColors: Record<string, string> = {
    SIGNAL: "bg-blue-500/10 text-blue-400",
    STOP_LOSS: "bg-danger-dim text-danger",
    TAKE_PROFIT: "bg-accent-dim text-accent",
    TRAILING_STOP: "bg-purple-500/10 text-purple-400",
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="font-heading text-xl font-bold">Tranzacții</h1>
        <p className="text-sm text-muted-foreground">Istoric complet al tranzacțiilor și analize</p>
      </div>

      {/* Filters */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Symbol Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Simbol:</span>
            <Select value={symbolFilter} onValueChange={setSymbolFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Toate" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Toate</SelectItem>
                {uniqueSymbols.map(symbol => (
                  <SelectItem key={symbol} value={symbol}>{symbol}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Type Filter */}
          {uniqueTypes.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Tip:</span>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Toate" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">Toate</SelectItem>
                  {uniqueTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Date Range Filters */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">De la:</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn("w-32 justify-start text-left font-normal text-xs", !fromDate && "text-muted-foreground")}
                >
                  <CalendarIcon className="mr-2 h-3 w-3" />
                  {fromDate ? format(fromDate, "dd/MM/yyyy") : "Selectează"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={fromDate}
                  onSelect={setFromDate}
                  initialFocus
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Până la:</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn("w-32 justify-start text-left font-normal text-xs", !toDate && "text-muted-foreground")}
                >
                  <CalendarIcon className="mr-2 h-3 w-3" />
                  {toDate ? format(toDate, "dd/MM/yyyy") : "Selectează"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={toDate}
                  onSelect={setToDate}
                  initialFocus
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Clear Filters */}
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-xs gap-1"
            >
              <X className="h-3 w-3" />
              Șterge filtrele
            </Button>
          )}
        </div>

        {/* Filter Summary */}
        {hasActiveFilters && (
          <div className="text-xs text-muted-foreground">
            Afișând {filteredTrades.length} din {trades.length} tranzacții
          </div>
        )}
      </div>
      {/* Financial Summary */}
      <div className="bg-card border border-border-subtle rounded-xl p-5 shadow-lg shadow-black/20">
        <h3 className="font-heading text-sm font-semibold mb-3">Sumar Financiar</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Volum BUY</p>
            <p className="font-mono text-lg font-semibold">{formatCurrency(totalInvested)}</p>
            <p className="text-[10px] text-muted-foreground">{buyTrades.length} ordine</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Volum SELL</p>
            <p className="font-mono text-lg font-semibold">{formatCurrency(totalReturned)}</p>
            <p className="text-[10px] text-muted-foreground">{sellTrades.length} ordine</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Realized P&L</p>
            <p className={`font-mono text-lg font-semibold ${totalPl >= 0 ? "text-accent" : "text-danger"}`}>{formatCurrency(totalPl)}</p>
            <p className="text-[10px] text-muted-foreground">din SELL-uri închise</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Volum Total</p>
            <p className="font-mono text-lg font-semibold">{formatCurrency(totalInvested + totalReturned)}</p>
            <p className="text-[10px] text-muted-foreground">{filteredTrades.length} tranzacții</p>
          </div>
        </div>
      </div>

      {/* Pie Chart - Distribution by Symbol */}
      {pieData.length > 0 && (
        <div className="bg-card border border-border-subtle rounded-xl p-5 shadow-lg shadow-black/20">
          <h3 className="font-heading text-sm font-semibold mb-3">Distribuție Investiții pe Simbol</h3>
          <div className="flex flex-col lg:flex-row items-center gap-4">
            <ResponsiveContainer width="100%" height={220} className="max-w-[280px]">
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={90}
                  paddingAngle={2}
                  strokeWidth={0}
                >
                  {pieData.map((_, idx) => (
                    <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ background: "hsl(217,33%,11%)", border: "1px solid hsl(215,19%,17%)", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => [formatCurrency(v), "Investit"]}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs">
              {pieData.map((d, idx) => (
                <div key={d.name} className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: PIE_COLORS[idx % PIE_COLORS.length] }} />
                  <span className="font-heading font-semibold">{d.name}</span>
                  <span className="text-muted-foreground font-mono">{formatCurrency(d.value)}</span>
                  <span className="text-muted-foreground/60">({((d.value / totalInvested) * 100).toFixed(1)}%)</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Total Trades", value: trades.length.toString() },
          { label: "Win Rate", value: `${winRate.toFixed(1)}%` },
          { label: "Realized P&L", value: formatCurrency(totalPl), color: totalPl >= 0 ? "text-accent" : "text-danger" },
          { label: "Best Trade", value: formatCurrency(bestTrade), color: "text-accent" },
        ].map(s => (
          <div key={s.label} className="bg-card border border-border-subtle rounded-xl p-4 shadow-lg shadow-black/20">
            <p className="text-xs text-muted-foreground mb-1">{s.label}</p>
            <p className={`font-mono text-lg font-semibold ${s.color ?? ""}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* P&L Bar Chart */}
      {plChartData.length > 0 && (
        <div className="bg-card border border-border-subtle rounded-xl p-5 shadow-lg shadow-black/20">
          <h3 className="font-heading text-sm font-semibold mb-3">P&L per Trade (Last 10)</h3>
          <ResponsiveContainer width="100%" height={120}>
            <BarChart data={plChartData}>
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: "hsl(218,11%,65%)" }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip
                contentStyle={{ background: "hsl(217,33%,11%)", border: "1px solid hsl(215,19%,17%)", borderRadius: 8, fontSize: 12 }}
                formatter={(v: number) => [formatCurrency(v), "P&L"]}
              />
              <Bar dataKey="pl" radius={[4, 4, 0, 0]}>
                {plChartData.map((entry, idx) => (
                  <Cell key={idx} fill={entry.pl >= 0 ? "hsl(160,84%,39%)" : "hsl(0,84%,60%)"} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Performance Analytics */}
      {performanceData.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Cumulative P&L Chart */}
          <div className="bg-card border border-border-subtle rounded-xl p-5 shadow-lg shadow-black/20">
            <h3 className="font-heading text-sm font-semibold mb-3">P&L Cumulativ</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={performanceData}>
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 10, fill: "hsl(218,11%,65%)" }} 
                  axisLine={false} 
                  tickLine={false} 
                />
                <YAxis 
                  tick={{ fontSize: 10, fill: "hsl(218,11%,65%)" }} 
                  axisLine={false} 
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{ background: "hsl(217,33%,11%)", border: "1px solid hsl(215,19%,17%)", borderRadius: 8, fontSize: 12 }}
                  formatter={(value: number, name: string) => [formatCurrency(value), name === 'cumulativePL' ? 'P&L Cumulativ' : name]}
                />
                <Line 
                  type="monotone" 
                  dataKey="cumulativePL" 
                  stroke="hsl(160,84%,39%)" 
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Daily Volume Chart */}
          <div className="bg-card border border-border-subtle rounded-xl p-5 shadow-lg shadow-black/20">
            <h3 className="font-heading text-sm font-semibold mb-3">Volum Zilnic</h3>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={performanceData}>
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 10, fill: "hsl(218,11%,65%)" }} 
                  axisLine={false} 
                  tickLine={false} 
                />
                <YAxis 
                  tick={{ fontSize: 10, fill: "hsl(218,11%,65%)" }} 
                  axisLine={false} 
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{ background: "hsl(217,33%,11%)", border: "1px solid hsl(215,19%,17%)", borderRadius: 8, fontSize: 12 }}
                  formatter={(value: number, name: string) => [
                    formatCurrency(value), 
                    name === 'buyVolume' ? 'Volum BUY' : name === 'sellVolume' ? 'Volum SELL' : name
                  ]}
                />
                <Area 
                  type="monotone" 
                  dataKey="buyVolume" 
                  stackId="1"
                  stroke="hsl(217,91%,60%)" 
                  fill="hsl(217,91%,60%)"
                  fillOpacity={0.6}
                />
                <Area 
                  type="monotone" 
                  dataKey="sellVolume" 
                  stackId="1"
                  stroke="hsl(160,84%,39%)" 
                  fill="hsl(160,84%,39%)"
                  fillOpacity={0.6}
                />
                <Legend />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Win Rate Trend */}
          {sellTrades.length > 0 && (
            <div className="bg-card border border-border-subtle rounded-xl p-5 shadow-lg shadow-black/20 lg:col-span-2">
              <h3 className="font-heading text-sm font-semibold mb-3">Trend Win Rate</h3>
              <ResponsiveContainer width="100%" height={160}>
                <LineChart data={performanceData.filter(d => d.winRate > 0)}>
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 10, fill: "hsl(218,11%,65%)" }} 
                    axisLine={false} 
                    tickLine={false} 
                  />
                  <YAxis 
                    tick={{ fontSize: 10, fill: "hsl(218,11%,65%)" }} 
                    axisLine={false} 
                    tickLine={false}
                    domain={[0, 100]}
                  />
                  <Tooltip
                    contentStyle={{ background: "hsl(217,33%,11%)", border: "1px solid hsl(215,19%,17%)", borderRadius: 8, fontSize: 12 }}
                    formatter={(value: number) => [`${value}%`, 'Win Rate']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="winRate" 
                    stroke="hsl(280,65%,60%)" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(280,65%,60%)", strokeWidth: 0, r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {/* Table */}
      <div className="bg-card border border-border-subtle rounded-xl shadow-lg shadow-black/20 overflow-hidden">
        {paged.length === 0 ? (
          <div className="p-12 text-center text-muted-foreground">No trades yet</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border-subtle text-xs text-muted-foreground">
                  <th className="text-left p-4 font-medium">Time</th>
                  <th className="text-left p-4 font-medium">Symbol</th>
                  <th className="text-left p-4 font-medium">Action</th>
                  <th className="text-left p-4 font-medium">Qty @ Price</th>
                  <th className="text-left p-4 font-medium hidden md:table-cell">Value</th>
                  <th className="text-left p-4 font-medium hidden lg:table-cell">Type</th>
                  <th className="text-left p-4 font-medium">P&L</th>
                  <th className="text-left p-4 font-medium hidden lg:table-cell">Confidence</th>
                </tr>
              </thead>
              <tbody>
                {paged.map((t) => {
                  const hasQty = t.qty != null && t.qty > 0;
                  const computedValue = hasQty && t.price ? t.qty * t.price : 0;
                  const displayValue = computedValue > 0 ? formatCurrencyPlain(computedValue) : t.value ? formatCurrencyPlain(t.value) : "—";

                  return (
                    <tr
                      key={t.id}
                      className={`border-b border-border-subtle/50 hover:bg-card-hover transition-colors duration-150 border-l-[3px] ${
                        t.action === "BUY" ? "border-l-accent/30" : "border-l-danger/30"
                      }`}
                    >
                      <td className="p-4 text-muted-foreground text-xs">
                        {t.timestamp ? format(new Date(t.timestamp), "MMM d, HH:mm") : "—"}
                      </td>
                      <td className="p-4 font-heading font-semibold">{t.symbol}</td>
                      <td className="p-4">
                        <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${t.action === "BUY" ? "bg-accent-dim text-accent" : "bg-danger-dim text-danger"}`}>
                          {t.action}
                        </span>
                      </td>
                      <td className="p-4 font-mono text-xs">
                        {hasQty ? `${t.qty} @ ` : ""}{formatCurrencyPlain(t.price)}
                      </td>
                      <td className="p-4 font-mono text-xs hidden md:table-cell">
                        {displayValue}
                      </td>
                      <td className="p-4 hidden lg:table-cell">
                        {t.close_type && (
                          <span className={`text-xs px-2 py-0.5 rounded-full ${typeColors[t.close_type] ?? "bg-secondary text-muted-foreground"}`}>
                            {t.close_type}
                          </span>
                        )}
                      </td>
                      <td className="p-4">
                        {t.action === "SELL" && t.pl != null && hasQty ? (
                          <span className={`font-mono font-semibold ${t.pl >= 0 ? "text-accent" : "text-danger"}`}>{formatCurrency(t.pl)}</span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </td>
                      <td className="p-4 hidden lg:table-cell">
                        {t.confidence != null && (
                          <div className="flex items-center gap-1.5">
                            <div className="w-12 h-1.5 bg-secondary rounded-full overflow-hidden">
                              <div className="h-full bg-accent rounded-full" style={{ width: `${t.confidence}%` }} />
                            </div>
                            <span className="font-mono text-xs text-muted-foreground">{t.confidence}%</span>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-border-subtle">
            <button
              onClick={() => setPage(p => Math.max(0, p - 1))}
              disabled={page === 0}
              className="px-3 py-1.5 text-xs rounded-lg border border-border-subtle hover:bg-card-hover transition-colors duration-150 disabled:opacity-30"
            >
              ← Previous
            </button>
            <span className="text-xs text-muted-foreground">{page + 1} / {totalPages}</span>
            <button
              onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
              className="px-3 py-1.5 text-xs rounded-lg border border-border-subtle hover:bg-card-hover transition-colors duration-150 disabled:opacity-30"
            >
              Next →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
